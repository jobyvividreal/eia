/*
 * Feature Discovery - Advanced UI
 */
$(function () {
    $('.tap-target').tapTarget();
});
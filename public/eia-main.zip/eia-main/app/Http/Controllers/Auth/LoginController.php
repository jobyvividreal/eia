<?php

namespace App\Http\Controllers\Auth;

use App\Helpers\FunctionHelper;
use App\Http\Controllers\Controller;
use App\Models\UserOtp;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Mail\UserLoginOtpMail;
use App\Rules\ReCaptcha;
use Auth;
use Carbon\Carbon;
use Mail;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    // Custom log in function
    public function login(Request $request)
    {
        $response['status'] = false;
        $input = $request->all();

        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users',
            'password' => 'required',
            // 'g-recaptcha-response' => ['required'],
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()]);
        }
        $user = User::where('email', $request->email)->first();
        $now = Carbon::now();
        $otp = "12345";
        if ($otp) {
            if ($user->otp->status == 1) {
                // if ($now <= $user->otp->updated_at->addMinute('5')) {
                    if ($user->otp->otp == $otp) {
                        UserOtp::updateOrCreate([
                            'user_id' => $user->id,
                        ], [
                            'status' => 0
                        ]);
                        $remember_me = $request->has('remember_me') ? true : false;
                        if (auth()->attempt(array('email' => $input['email'], 'password' => $input['password']), $remember_me)) {

                            if (!auth()->user()->status == 1) {
                                Auth::logout();
                                $response['message'] = 'Account is not active, Please try again later or contact support.';
                                $response['route'] =  'login';
                                return $response;
                            }

                            if (auth()->user()->is_admin == 1) {
                                $response['status'] = true;
                                $response['route'] =  'admin/dashboard';
                                return $response;
                            } else {
                                $response['status'] = true;
                                $response['route'] =  'dashboard';
                                return $response;
                            }
                        } else {
                            $response['message'] = 'The Username or Password is incorrect.';
                            $response['route'] =  'login';
                            return $response;
                        }
                    } else {
                        $response['otp'] = 1;
                        $response['message'] = 'Something went wrong. Please check OTP!';
                        $response['route'] =  'login';
                        return $response;
                    }
                // } else {
                //     UserOtp::updateOrCreate([
                //         'user_id' => $user->id,
                //     ], [
                //         'status' => 0
                //     ]);
                //     $response['otp'] = 1;
                //     $response['message'] = 'Time expired for OTP. Please retry!';
                //     $response['route'] =  'login';
                //     return $response;
                // }
            } else {
                $response['otp'] = 1;
                $response['message'] = 'OTP expired !';
                $response['route'] =  'login';
                return $response;
            }
        } else {
            // if (!isset($user->otp) || $now > $user->otp->updated_at->addMinute('5') || $user->otp->status == 0) {
                $otp = FunctionHelper::generateRandomCode();
                UserOtp::updateOrCreate([
                    'user_id' => $user->id,
                ], [
                    'otp' => $otp,
                    // 'status' => 1
                ]);
                $user = User::where('email', $request->email)->first();
                Mail::to($request->email)->send(new UserLoginOtpMail($user));
                $response['otp'] = 1;
                $response['message'] = 'Please check your mail for OTP.';
                return $response;
            // } else {
            //     $response['message'] = 'Please check your mail for OTP.';
            //     $response['otp'] = 1;
            //     return $response;
            // }
        }
    }
}

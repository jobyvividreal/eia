<?php

return [
    'List' => 'قائمة',
    'Active' => 'نشيط',
    'Inactive' => 'غير نشط',
    'No.' => 'رقم.',
    'Name' => 'اسم',
    'Mobile' => 'متحرك',
    'E-mail' => 'بريد الالكتروني',
    'Roles' => 'الأدوار',
    'Status' => 'حالة',
    'Action' => 'عمل',
    'Dashboard' => 'لوحة القيادة',
    'Users' => 'المستخدمون',
    'Masters' => 'سادة',
    'Designations' => 'تعيين',
    'Project Category' => 'فئة المشروع',
    'Create New' => 'خلق جديد إبداع جديد',
    'Form' => 'استمارة',    
    'Please enter' => 'تفضل',
    'Errors Occurred. Please check !' => 'حدثت أخطاء. يرجى المراجعة !',
    'Project Types' => 'نوع المشروع',
    'Departments' => 'الإدارات',
    'Companies' => 'شركات',
    'Permissions' => 'أذونات',
        
];
?>
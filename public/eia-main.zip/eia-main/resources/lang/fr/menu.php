<?php

return [
    'Dashboard' => 'Dashboard FR',
];
?>
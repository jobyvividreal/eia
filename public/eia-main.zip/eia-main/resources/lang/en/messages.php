<?php

return [
    
    'Dummy Text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry',
    'apples' => 'There is one apple|There are many apples',
    'title' => 'Comments',
];
?>
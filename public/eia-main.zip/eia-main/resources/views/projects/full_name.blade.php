<div id="fullNameModel" class="modal">
      <div class="modal-content">
          <a class="btn-floating mb-1 waves-effect waves-light right modal-close"><i class="material-icons">clear</i></a>
          <div class="card-body" id="">
              <p id="projectFullName"> </p>
          </div>
      </div>
</div>
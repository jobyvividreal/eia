

<!-- START: Footer-->
<footer class="page-footer footer footer-static footer-dark gradient-45deg-light-blue-cyan gradient-shadow navbar-border navbar-shadow">
  <div class="footer-copyright">
    <div class="container">
      <span>&copy; {{ date('Y') }}<a href="https://vividreal.com/" target="_blank">{{ config('app.name') }}</a> All rights reserved.</span>
      <span class="right hide-on-small-only"> Design and Developed by <a href="https://vividreal.com/" target="_blank">Vividreal</a></span>
    </div>
  </div>
</footer>
<!-- END: Footer-->

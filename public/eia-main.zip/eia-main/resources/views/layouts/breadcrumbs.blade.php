
<div class="pt-1 pb-0" id="breadcrumbs-wrapper">
  <!-- Search for small screen-->
  <div class="container">
      <div class="row">    
        @yield('breadcrumb')
      </div>
  </div>
</div>
<?php $__env->startSection('seo_title', Str::plural($page->title) ?? ''); ?> 
<?php $__env->startSection('search-title'); ?> <?php echo e($page->title ?? ''); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('vendor-style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="col s12 m6 l6"><h5 class="breadcrumbs-title"><span><?php echo e(Str::plural(__('locale.'.$page->title)) ?? ''); ?></span></h5></div>
<div class="col s12 m6 l6 right-align-md">
    <ol class="breadcrumbs mb-0">
        <li class="breadcrumb-item"><a href="<?php echo e(url(ROUTE_PREFIX.'/dashboard')); ?>"><?php echo e(__('locale.Dashboard')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url($page->route)); ?>"><?php echo e(Str::plural(__('locale.'.$page->title)) ?? ''); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(__('locale.Create')); ?></li>
    </ol>
</div>
<?php $__env->stopSection(); ?>
<div class="seaction">
    <div class="card">
        <div class="card-content">
            <p class="caption mb-0"><?php echo e(__('messages.Dummy Text')); ?></p>
        </div>
    </div>
    <!--Basic Form-->
    <!-- jQuery Plugin Initialization -->
    <div class="row">
        <!-- Form Advance -->
        <div class="col s12 m12 l12">
            <div id="Form-advance" class="card card card-default scrollspy">
                <div class="card-content">
                    <div class="card-title">
                        <div class="row right">
                            <div class="col s12 m12 ">
                                <?php echo App\Helpers\HtmlHelper::listLinkButton(url($page->route), __('locale.List') . '' . Str::plural(__('locale.'.$page->title))  ); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col s12 m6 ">
                                <h4 class="card-title"><?php echo e(Str::singular(__('locale.'.$page->title)) ?? ''); ?> <?php echo e(__('locale.Form')); ?></h4>
                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <?php echo Form::open(['class'=>'ajax-submit','id'=> Str::camel($page->title).'Form']); ?>

                        <?php echo e(csrf_field()); ?>

                        <?php echo Form::hidden('projectTypeId', $projectType->id ?? '', ['id' => 'projectTypeId'] ); ?>

                        <?php echo Form::hidden('pageTitle', Str::camel($page->title), ['id' => 'pageTitle'] ); ?> 
                        <?php echo Form::hidden('pageRoute', url($page->route), ['id' => 'pageRoute'] ); ?>


                        <div class="row">
                            <div class="input-field col m6 s12">
                                <?php echo Form::text('name', $projectType->name ?? '', array('id' => 'name')); ?>

                                <label for="name" class="label-placeholder active"> Title <span class="red-text">*</span></label>
                            </div>
                            <div class="input-field col m6 s12">
                                <?php echo Form::textarea('description', $projectType->description ?? '',  ['id' => 'description', 'class' => 'materialize-textarea']); ?>

                                <label for="description" class="label-placeholder active"> Description </label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <?php echo App\Helpers\HtmlHelper::submitButton('Submit', 'projectTypeSubmitBtn'); ?>

                                <?php echo App\Helpers\HtmlHelper::resetButton('Reset', 'formResetBtn'); ?>

                            </div>
                        </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div><!-- START RIGHT SIDEBAR NAV -->
<?php $__env->stopSection(); ?>



<?php $__env->startSection('vendor-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
<script src="<?php echo e(asset('admin/js/custom/project_types/project_types.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/admin/project_types/create.blade.php ENDPATH**/ ?>
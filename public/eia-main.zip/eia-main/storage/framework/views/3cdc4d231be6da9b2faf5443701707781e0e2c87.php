<?php $__env->startSection('seo_title', Str::plural(__('locale.Users')) ?? ''); ?> 
<?php $__env->startSection('search-title'); ?> <?php echo e(__('locale.Users') ?? ''); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('vendor-style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="col s12 m6 l6"><h5 class="breadcrumbs-title"><span><?php echo e(Str::plural(__('locale.Roles')) ?? ''); ?></span></h5></div>
<div class="col s12 m6 l6 right-align-md">
  <ol class="breadcrumbs mb-0">
    <li class="breadcrumb-item"><a href="<?php echo e(url(ROUTE_PREFIX.'/dashboard')); ?>"><?php echo e(__('locale.Dashboard')); ?></a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(url($page->route)); ?>"><?php echo e(Str::plural(__('locale.Users')) ?? ''); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('locale.List')); ?></li>
  </ol>
</div>
<?php $__env->stopSection(); ?>
<div class="section">
  <div class="card">
    <div class="card-content">
      <p class="caption mb-0"><?php echo e(__('messages.Dummy Text')); ?>.</p>
    </div>
  </div>
  <!-- Borderless Table -->
  <div class="row">
    <div class="col s12">
      <div id="borderless-table" class="card card-tabs">
        <div class="card-content data-table-container">
          <div class="card-title">
            <div class="row right">
              <div class="col s12 m12 ">
                <!-- <?php echo App\Helpers\HtmlHelper::createLinkButton(url($page->route.'/create'), __('locale.Create New'). ' ' .Str::singular(__('locale.'.__('locale.'.$page->title))), ); ?> -->
              </div>
            </div>
            <div class="row">
              <div class="col s12 m6 ">
                <h4 class="card-title"><?php echo e(Str::singular(__('locale.'.$page->title)) ?? ''); ?> List</h4>
              </div>
            </div>
          </div>
          <div id="view-borderless-table">
            <div class="row">
              <div class="col s12">
                <?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <table class="display">
                  <thead>
                    <tr>
                      <th width="20px" data-orderable="false" data-column="DT_RowIndex"> No </th>
                      <th width="200px" data-orderable="false" data-column="name"> Name </th>
                      <th width="150px" data-orderable="false" data-column="action"> Action </th>
                    </tr>
                  </thead>
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($loop->index+1); ?></td>
                      <td><?php echo e($role->name); ?></td>
                      <td> 
                        <!-- <a href="<?php echo e(url(ROUTE_PREFIX.'/roles/'.$role->id)); ?>" class="btn mr-2 blue tooltipped" data-tooltip="View details"><i class="material-icons">visibility</i></a> -->
                        <a href="<?php echo e(url(ROUTE_PREFIX.'/roles/'.$role->id.'/edit')); ?>" class="btn mr-2 orange tooltipped" data-tooltip="Manage Permissions"><i class="material-icons">vpn_key</i></a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                          <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id], 'name'=>'roleForm', 'style'=>'display:inline']); ?>

                            <!-- <a href="javascript:void(0);" id="<?php echo e($role->id); ?>" class="btn btn-sm btn-icon mr-2 role-delete-btn" title="Delete Role"><i class="material-icons">cancel</i> </a> -->
                          <?php echo Form::close(); ?>

                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><!-- START RIGHT SIDEBAR NAV -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-scripts'); ?>
<script src="<?php echo e(asset('admin/js/scripts/data-tables.js')); ?>"></script>
<script>
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/admin/roles/list.blade.php ENDPATH**/ ?>
<?php $__env->startSection('seo_title', Str::plural(__('locale.Users')) ?? ''); ?> 
<?php $__env->startSection('search-title'); ?> <?php echo e(__('locale.Users') ?? ''); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('vendor-style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="col s12 m6 l6"><h5 class="breadcrumbs-title"><span><?php echo e(Str::plural(__('locale.Users')) ?? ''); ?></span></h5></div>
<div class="col s12 m6 l6 right-align-md">
    <ol class="breadcrumbs mb-0">
        <li class="breadcrumb-item"><a href="<?php echo e(url(ROUTE_PREFIX.'/dashboard')); ?>"><?php echo e(__('locale.Dashboard')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url($page->route)); ?>"><?php echo e(Str::plural(__('locale.Users')) ?? ''); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(__('locale.List')); ?></li>
    </ol>
</div>
<?php $__env->stopSection(); ?>
<div class="section">
  <div class="card">
      <div class="card-content">
          <p class="caption mb-0"><?php echo e(__('messages.Dummy Text')); ?>.</p>
      </div>
  </div>

  <!-- Borderless Table -->
  <div class="row">
      <div class="col s12">
          <div id="borderless-table" class="card card-tabs">
              <div class="card-content data-table-container">
                  <div class="card-title">
                      <div class="row right">
                        <div class="col s12 m12 ">
                            <?php echo App\Helpers\HtmlHelper::createLinkButton(url($page->route.'/create'), __('locale.Create New'). ' ' .Str::singular(__('locale.'.__('locale.'.$page->title))), ); ?>

                            <a class="dropdown-settings btn mb-1 waves-effect waves-light cyan" href="#!" data-target="dropdown1" id="customerListBtn"><i class="material-icons hide-on-med-and-up">settings</i><span class="hide-on-small-onl"> <?php echo e(__('locale.List'). ' ' . Str::plural(__('locale.'.$page->title))); ?></span><i class="material-icons right">arrow_drop_down</i></a>
                            <ul class="dropdown-content" id="dropdown1" tabindex="0">
                              <li tabindex="0"><a class="grey-text text-darken-2 listBtn active" data-type="active" href="javascript:" > <?php echo e(__('locale.Active')); ?> </a></li>
                              <li tabindex="0"><a class="grey-text text-darken-2 listBtn" data-type="disabled" href="javascript:"> <?php echo e(__('locale.Inactive')); ?> </a></li>
                            </ul>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col s12 m6 ">
                            <h4 class="card-title"><?php echo e(Str::singular(__('locale.'.$page->title)) ?? ''); ?> List</h4>
                        </div>
                      </div>
                      <div class="row">
                          <form id="page-form" name="page-form">
                            <?php echo Form::hidden('user_type', '', ['id' => 'user_type'] ); ?>

                            <?php echo Form::hidden('status', '', ['id' => 'status'] ); ?>

                            <div class="col s12 m3">
                                <label for="users-list-verified">User Details</label>
                                <div class="input-field">
                                  <?php echo Form::text('name', '' , ['id' => 'name']); ?>

                                  <label for="name" class="label-placeholder active">User Name, Email or Mobile </label>
                                </div>
                            </div>
                            <div class="col s12 m3">
                                <label for="users-list-role">Role</label>
                                <div class="input-field" style="margin-top:8px">
                                  <?php echo Form::select('roles[]', $variants->roles , [], ['id' => 'roles' ,'class' => 'select2 browser-default form-control', 'multiple' => 'multiple' ]); ?>

                                </div>
                            </div>
                            
                            <div class="col s12 m4 display-flex show-btn">
                              <div class="col s12 ">
                                <button type="button" class="btn btn-block indigo waves-effect waves-light" id="page-show-result-button" style="margin-top: 60px;">Show Result</button>
                              </div>
                              <div class="col s12 ">
                                <button type="button" class="btn btn-block indigo waves-effect waves-light" id="page-clear-button" style="margin-top: 60px;">Clear</button>
                              </div>
                            </div>
                        </form>
                      </div>
                  </div>
                  <div id="view-borderless-table">
                    <div class="row">
                      <div class="col s12">
                        <table id="data-table-billing" class="display data-tables" data-url="<?php echo e($page->link.'/lists'); ?>" data-form="page" data-length="10">
                          <thead>
                              <tr>
                                  <th width="20px" data-orderable="false" data-column="DT_RowIndex"> No </th>
                                  <th width="200px" data-orderable="false" data-column="name"> Name </th>
                                  <th width="200px" data-orderable="false" data-column="email"> E-mail </th>
                                  <th width="150px" data-orderable="false" data-column="mobile"> Mobile </th>
                                  <th width="250px" data-orderable="false" data-column="role"> Roles </th>
                                  <th width="100px" data-orderable="false" data-column="status"> Status </th>
                                  <th width="150px" data-orderable="false" data-column="action"> Action </th>
                              </tr>
                              </thead>
                        </table>
                      </div>
                    </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div><!-- START RIGHT SIDEBAR NAV -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
<script src="<?php echo e(asset('admin/js/scripts/data-tables.js')); ?>"></script>
<script>
$('#roles').select2({ placeholder: "Please choose roles", allowClear: true });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/admin/users/list.blade.php ENDPATH**/ ?>
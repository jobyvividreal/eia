<div id="data-create-modal" class="modal">
  <?php echo Form::open(['class'=>'ajax-submit', 'id'=> 'assignTaskForm']); ?>

    <div class="modal-content">
      <a class="btn-floating mb-1 waves-effect waves-light right modal-close"><i class="material-icons">clear</i></a>
      <div class="modal-header"><h4 class="modal-title">Assign Task Form</h4> </div>
      <?php echo e(csrf_field()); ?>

      <?php echo Form::hidden('document_id', $document->id, ['id' => 'documentId'] ); ?>

      <?php echo Form::hidden('assignedId', $assignedId ?? '', ['id' => 'assignedId'] ); ?>

      <?php echo Form::hidden('assignRoute', url('task-assign'), ['id' => 'assignRoute'] ); ?>

      <div class="card-body" id="">
        <div class="row">
          <div class="input-field col s12">
            <?php echo Form::select('assigned_to', $variants->users, '', ['id' => 'assigned_to', 'class' => 'select2 browser-default task-store-input', 'placeholder'=>'Please select User']); ?>

            <!-- <label for="assigned_to" class="label-placeholder active"> Please select User <span class="red-text">*</span> </label> -->
          </div>
          <div class="input-field col s12">
            <?php echo Form::textarea('details', '', ['id' => 'details', 'class' => 'materialize-textarea task-store-input', 'placeholder' => 'Task Details']); ?>

          </div>       
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('documents-task-complete')): ?>   
            <div class="input-field col s12 task-complete-checkbox" style="display:none;">
              <p class="mb-1"><label><input type="checkbox" id="taskCompleted" name="taskCompleted"> <span>Task Completed</span></label></p>
              <p><label>Check to complete the task</label></p>
            </div>
            <div class="input-field col s12 task-completed-section" style="display:none;">
              <?php echo Form::textarea('completedNote', '', ['id' => 'completedNote', 'class' => 'materialize-textarea', 'placeholder' => 'Please enter note']); ?>

            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn waves-effect waves-light modal-action modal-close" type="reset" id="resetForm">Close</button>
      <button class="btn cyan waves-effect waves-light store-task" type="submit" name="action" id="formSubmitBtn">Submit <i class="material-icons right">send</i></button>
      <!-- <button class="btn cyan waves-effect waves-light update-task" type="button" name="action" id="taskCompleteBtn">Complete Task <i class="material-icons right">send</i></button> -->
    </div>
  <?php echo e(Form::close()); ?>

</div><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/documents/assign_task.blade.php ENDPATH**/ ?>
<?php $__env->startSection('seo_title', Str::plural(__('locale.'.$page->title)) ?? ''); ?> 
<?php $__env->startSection('search-title'); ?> <?php echo e(__('locale.'.$page->title) ?? ''); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('vendor-style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="col s12 m6 l6"><h5 class="breadcrumbs-title"><span><?php echo e(Str::plural(__('locale.'.$page->title)) ?? ''); ?></span></h5></div>
<div class="col s12 m6 l6 right-align-md">
    <ol class="breadcrumbs mb-0">
        <li class="breadcrumb-item"><a href="<?php echo e(url(ROUTE_PREFIX.'/dashboard')); ?>"><?php echo e(__('locale.Dashboard')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url($page->route)); ?>"><?php echo e(Str::plural(__('locale.'.$page->title)) ?? ''); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(__('locale.List')); ?></li>
    </ol>
</div>
<?php $__env->stopSection(); ?>
<div class="section">
  <div class="card">
      <div class="card-content">
          <p class="caption mb-0"><?php echo e(__('messages.Dummy Text')); ?>.</p>
      </div>
  </div>

  <!-- Borderless Table -->
  <div class="row">
      <div class="col s12">
          <div id="borderless-table" class="card card-tabs">
              <div class="card-content data-table-container">
                  <div class="card-title">
                      <div class="row right">
                        <div class="col s12 m12 ">
                            <?php echo App\Helpers\HtmlHelper::createLinkButton(url($page->route.'/create'), __('locale.Create New'). ' ' .Str::singular(__('locale.'.$page->title))); ?>

                            <?php echo App\Helpers\HtmlHelper::listLinkButton(url($page->route), __('locale.List'). ' ' . Str::plural(__('locale.'.$page->title)), ); ?>

                        </div>
                      </div>
                      <div class="row">
                        <div class="col s12 m6 ">
                            <h4 class="card-title"><?php echo e(Str::singular(__('locale.'.$page->title)) ?? ''); ?> <?php echo e(__('locale.List')); ?></h4>
                        </div>
                      </div>
                      <div class="row">
                          <form id="page-form" name="page-form">
                        </form>
                      </div>
                  </div>
                  <div id="view-borderless-table">
                    <div class="row">
                      <div class="col s12">
                        <table id="data-table-projectType" class="display data-tables" data-url="<?php echo e($page->link.'/lists'); ?>" data-form="page" data-length="10">
                          <thead>
                              <tr>
                                  <th width="20px" data-orderable="false" data-column="DT_RowIndex"> No </th>
                                  <th width="" data-orderable="false" data-column="name"> Name </th>
                                  <th width="100px" data-orderable="false" data-column="status"> Status </th>
                                  <th width="200px" data-orderable="false" data-column="action"> Action </th>
                              </tr>
                              </thead>
                        </table>
                      </div>
                    </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div><!-- START RIGHT SIDEBAR NAV -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
<script src="<?php echo e(asset('admin/js/scripts/data-tables.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom/project_types/project_types.js')); ?>"></script>
<script>
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/admin/project_types/list.blade.php ENDPATH**/ ?>
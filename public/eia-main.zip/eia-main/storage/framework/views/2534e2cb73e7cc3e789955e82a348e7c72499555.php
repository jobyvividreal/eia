<div id="viewMoreDetailsModel" class="modal">
      <div class="modal-content">
          <a class="btn-floating mb-1 waves-effect waves-light right modal-close"><i class="material-icons">clear</i></a>
          <div class="card-body" id="">
              <p id="fullTextSection"> </p>
          </div>
      </div>
</div><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/layouts/full-text.blade.php ENDPATH**/ ?>
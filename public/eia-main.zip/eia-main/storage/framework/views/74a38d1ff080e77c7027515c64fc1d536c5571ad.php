
<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
    <base href="<?php echo e(url('/')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link rel="shortcut icon" href="<?php echo e(asset('admin/images/favicon.ico')); ?>"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('admin/images/favicon/apple-touch-icon-152x152.png')); ?>">

    <!-- <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="icon" href="/favicon.ico" type="image/x-icon"> -->

    <title><?php echo e(config('app.name')); ?>

    <?php if(!Request::is('/')): ?>
     | <?php echo $__env->yieldContent('seo_title', ''); ?>
    <?php endif; ?>
    </title>
    <meta name="description" content="<?php echo $__env->yieldContent('seo_keyword', ''); ?>">
    <meta name="keyword" content="<?php echo $__env->yieldContent('seo_description', ''); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/pages/page-404.css')); ?>">
    <?php echo $__env->make('layouts.general_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

</head>
<body class="vertical-layout vertical-menu-collapsible page-header-dark vertical-modern-menu 1-column bg-full-screen-image blank-page blank-page" data-open="click" data-menu="vertical-modern-menu" data-col="1-column">
    <div class="row">
      <div class="col s12">
        <div class="container"><div class="section section-404 p-0 m-0 height-100vh">
  <div class="row">
    <!-- 404 -->
    <div class="col s12 center-align white">
      <img src="<?php echo e(asset('admin/images/gallery/error-2.png')); ?>" class="bg-image-404" alt="">
      <h1 class="error-code m-0">404</h1>
      <h6 class="mb-2">BAD REQUEST</h6>
      <a class="btn waves-effect waves-light gradient-45deg-deep-purple-blue gradient-shadow mb-4" href="<?php echo e(url()->previous()); ?>">Back</a>
    </div>
  </div>
</div>
        </div>
        <div class="content-overlay"></div>
      </div>
    </div>
</body>
</html>



<?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/errors/404.blade.php ENDPATH**/ ?>
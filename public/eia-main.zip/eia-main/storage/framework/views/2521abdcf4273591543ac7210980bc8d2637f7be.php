<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
    <base href="<?php echo e(url('/')); ?>">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="<?php echo $__env->yieldContent('seo_keyword', ''); ?>">
    <meta name="keyword" content="<?php echo $__env->yieldContent('seo_description', ''); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="author" content="EIA">
    <title><?php echo e(config('app.name')); ?> <?php if(!Request::is('/')): ?> | <?php echo $__env->yieldContent('seo_title', ''); ?> <?php endif; ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('admin/images/favicon.ico')); ?>"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('admin/images/favicon/apple-touch-icon-152x152.png')); ?>">
    <?php echo $__env->make('layouts.general_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</head>
<body class="horizontal-layout page-header-light horizontal-menu preload-transitions 2-columns " data-open="click" data-menu="horizontal-menu" data-col="2-columns">
    <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div id="main" class="">
      <div class="row">
        <?php echo $__env->make('layouts.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        <div class="col s12">
          <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
          </div>
          <div class="content-overlay"></div>
        </div>
      </div>
    </div>
  <!-- END: Page Main-->
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.general_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldPushContent('page-scripts'); ?>
</body>
</html>
<?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/layouts/admin/app.blade.php ENDPATH**/ ?>
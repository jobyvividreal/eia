<?php $__env->startSection('content'); ?>
    <div id="login-page" class="row">
        
        <div class="col s12 m6 l4 z-depth-4 card-panel border-radius-6 login-card bg-opacity-8">
            <form method="POST" id="loginSubmit">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="input-field col s12" style="text-align:center">
                    <img src="<?php echo e(asset('admin/images/logo/logo.png')); ?>" alt="materialize logo">
                </div>
                <div class="input-field col s12">
                <h5 class="ml-4" style="text-align:center">Sign in </h5>
                </div>
            </div>
            <?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row margin">
                <div class="input-field col s12">
                <i class="material-icons prefix pt-2">person_outline</i>
                <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" class="validate" autocomplete="off" style="padding-left: 20px;">
                <label for="email" class="label-placeholder">User ID </label>
                </div>
            </div>
            <div class="row margin">
                <div class="input-field col s12">
                <i class="material-icons prefix pt-2">lock_outline</i>
                <input id="password" type="password" name="password" class="validate" autocomplete="off" style="padding-left: 20px;">
                <label for="password" class="label-placeholder">Password </label>
                </div>
            </div>
            <div class="row">
                <div class="col s12 m12 l12 ml-2 mt-1">
                <p style="margin-left: 2%;">
                    <label>
                    <input type="checkbox" name="remember_me" id="remember_me" />
                    <span>Remember Me</span>
                    </label>
                </p>
                </div>
            </div>
            <div class="row">
            <div class="col s12 m12 l12 ml-2 mt-1">
                    <div class="form-group" style="margin-left: 2%;">
                        <div class="g-recaptcha" data-sitekey="<?php echo e(Config::get('recaptcha.api_site_key')); ?>"></div>
                    </div>  
                </div>
            </div>
            <div class="row margin" id="otpDiv">
                <div class="input-field col s12" style="margin-left: 2%;">
                <!-- <i class="material-icons prefix pt-2">person_outline</i> -->
                <input id="otp" type="text" name="otp" value="" class="validate" autocomplete="off" style="padding-left: 20px;">
                <label for="email" class="label-placeholder">OTP</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s12">
                <button class="btn waves-effect waves-light border-round gradient-45deg-purple-deep-orange col s12" type="submit" name="action">Login 
                    <!-- <span class="loginSpinner"> -->
                        <i class="material-icons loginSpinner">loop</i>
                    <!-- </span> -->
                </button>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6 m6 l6">
                <!-- <p class="margin medium-small"><a href="javascript:">Register Now!</a></p> -->
                </div>
                <div class="input-field col s6 m6 l6">
                <p class="margin right-align medium-small"><a href="<?php echo e(url('forget-password')); ?>">Forgot password ?</a></p>
                </div>
            </div>
            </form>
        </div>
    </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="<?php echo e(asset('admin/js/common-script.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
<script type="text/javascript">
    $(".alert-danger").delay(1000).addClass("in").toggle(true).fadeOut(3000);
    $(".card-alert .close").click(function(){$(this).closest(".card-alert").fadeOut("slow")});
    $('#otpDiv').hide();
    $('.loginSpinner').hide();
    $('#loginSubmit').on('submit',function(e){
        e.preventDefault();
        $('.loginSpinner').show();
        $(".print-error-msg").css("display", "none");
        $('.print-error-msg ul').empty()
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: "<?php echo e(route('login')); ?>",
            type:"POST",
            data: {
                'email': $('#email').val(),
                'password': $('#password').val(),
                'otp': $('#otp').val(),
                'g-recaptcha-response': grecaptcha.getResponse()
            },
            success:function(response){
                $('.loginSpinner').hide();
                if(response.errors) {
                    $(".print-error-msg").css("display", "block")
                    jQuery.each(response.errors, function(key, value){
                        $('.print-error-msg ul').append('<li>'+value+'</li>');
                    });
                    $('#otpDiv').hide();
                } else if(response.status === false){
                    $(".print-error-msg").css("display", "block");
                    $('.print-error-msg ul').append('<li>'+response.message+'</li>');
                    if(response.otp ==1){
                        $('#otpDiv').show();
                    }
                } else if(response.status === true){
                    console.log(response);
                    $('#otpDiv').show();
                    window.location.href = response.route;
                }
            },
            error: function(response) {
                $('#otpDiv').hide();
                jQuery.each(response.errors, function(key, value){
                    $('.print-error-msg ul').append('<li>'+value+'</li>');
                });
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>


 

<?php echo $__env->make('auth.auth_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/auth/login.blade.php ENDPATH**/ ?>


<?php if(Session::has('success')): ?>
<div class="card-alert card gradient-45deg-green-teal print-success-msg">
  <div class="card-content white-text">
    <p><i class="material-icons">check</i> <?php echo Session::get('success'); ?></p>
  </div>
  <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">×</span>
  </button>
</div>
<?php endif; ?>
 

                    <?php /**PATH /home/eia/public_html/public/eia-main/resources/views/layouts/success.blade.php ENDPATH**/ ?>
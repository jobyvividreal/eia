<?php $__env->startSection('content'); ?>
<tr>
    <td style="padding:0 35px;">
        <h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:32px;font-family:'Rubik',sans-serif;">Dear <?php echo e($user->full_name); ?>, </h1>
        <h3 style="color:#1e1e2d; font-weight:500; margin:0;font-size:32px;font-family:'Rubik',sans-serif;">Welcome to <?php echo e(config('app.name')); ?></h3>
        <span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span>
        <p style="color:#455056; font-size:15px;line-height:24px; margin:0;">
            The OTP is <b> <?php echo e($user->otp->otp); ?> </b>. This OTP valid only for 5 minutes.
        </p>
    </td>
</tr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/email/otp.blade.php ENDPATH**/ ?>
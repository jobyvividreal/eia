<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
    <base href="<?php echo e(url('/')); ?>">
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="keywords" content="<?php echo $__env->yieldContent('seo_description', ''); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="author" content="ThemeSelect">

    <link rel="apple-touch-icon" href="<?php echo e(asset('admin/images/favicon/apple-touch-icon-152x152.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('admin/images/favicon.ico')); ?>"/>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- BEGIN: VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/vendors/vendors.min.css')); ?>">
    <!-- END: VENDOR CSS-->

    <!-- BEGIN: Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/themes/horizontal-menu-template/materialize.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/themes/horizontal-menu-template/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/layouts/style-horizontal.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/pages/login.css')); ?>">
    <!-- END: Page Level CSS-->
    
    <link rel=canonical href="<?php echo e(url('/')); ?>"/>
    <title>Login | <?php echo e(config('app.name')); ?> </title>
    <?php echo $__env->yieldPushContent('page-css'); ?>
</head>
<body class="vertical-layout vertical-menu-collapsible page-header-dark vertical-modern-menu preload-transitions 1-column login-bg blank-page" data-open="click" data-menu="vertical-modern-menu" data-col="1-column">

        <div class="row">
          <div class="col s12">
              <div class="container">
              
              <?php echo $__env->yieldContent('content'); ?>

              </div>
              <div class="content-overlay"></div>


      </div>
  </div>
    <script src="<?php echo e(asset('admin/js/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/toastr/toastr.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('page-scripts'); ?>

</body>
</html>
<?php /**PATH /home/eia/public_html/public/eia-main/resources/views/auth/auth_app.blade.php ENDPATH**/ ?>
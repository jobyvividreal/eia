
<div class="pt-1 pb-0" id="breadcrumbs-wrapper">
  <!-- Search for small screen-->
  <div class="container">
      <div class="row">    
        <?php echo $__env->yieldContent('breadcrumb'); ?>
      </div>
  </div>
</div><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/layouts/breadcrumbs.blade.php ENDPATH**/ ?>
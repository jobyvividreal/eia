
<!-- Validator Return  -->
<?php if(count($errors) > 0): ?>
  <div class="card-alert card red">
    <div class="card-content white-text">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><i class="material-icons">error</i> <?php echo e($error); ?></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">×</span>
    </button>
  </div>
<?php endif; ?>

<!-- Validator Return with ajax-->
<div class="card-alert card red print-error-msg" style="display:none">
  <div class="card-content white-text">
    <ul></ul>
  </div>
  <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">×</span>
  </button>
</div>

<!-- Validator Return with redirect -->
<?php if(Session::has('error')): ?>
  <div class="card-alert card red">
    <div class="card-content white-text">
      <p><i class="material-icons">error</i> <?php echo Session::get('error'); ?></p>
    </div>
    <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">×</span>
    </button>
  </div>
<?php endif; ?>


<?php if(Session::has('document-archived')): ?>
<div class="card-alert card orange">
    <div class="card-content white-text">
      <p><i class="material-icons">error</i> <?php echo Session::get('document-archived'); ?></p>
    </div>
    <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">×</span>
    </button>
  </div>
  <?php endif; ?>



<?php /**PATH /home/eia/public_html/public/eia-main/resources/views/layouts/error.blade.php ENDPATH**/ ?>
<?php $__env->startSection('seo_title', Str::plural($page->title) ?? ''); ?> 
<?php $__env->startSection('search-title'); ?> <?php echo e($page->title ?? ''); ?> <?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="col s12 m6 l6"><h5 class="breadcrumbs-title"><span><?php echo e(Str::plural(__('locale.'.$page->title)) ?? ''); ?></span></h5></div>
<div class="col s12 m6 l6 right-align-md">
    <ol class="breadcrumbs mb-0">
        <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>"><?php echo e(__('locale.Dashboard')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url($page->route)); ?>"><?php echo e(Str::plural(__('locale.'.$page->title)) ?? ''); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(__('locale.List')); ?></li>
    </ol>
</div>
<?php $__env->stopSection(); ?>
<div class="section">
  <div class="card">
      <div class="card-content">
          <p class="caption mb-0">Companies that operate Oil and Gas projects in Iraq</p>
      </div>
  </div>

  <!-- Borderless Table -->
  <div class="row">
      <div class="col s12">
          <div id="borderless-table" class="card card-tabs">
              <div class="card-content data-table-container">
                  <div class="card-title">
                    <div class="row right">
                      <div class="col s12 m12 ">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('companies-create')): ?>
                          <?php echo App\Helpers\HtmlHelper::createLinkButton(url($page->route.'/create'), __('locale.Create New'). ' ' .Str::singular(__('locale.'.$page->title))); ?>

                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('companies-list')): ?>
                          <a class="dropdown-settings btn mb-1 waves-effect waves-light cyan" href="#!" data-target="dropdown1" id="customerListBtn"><i class="material-icons hide-on-med-and-up">settings</i><span class="hide-on-small-onl"> <?php echo e(__('locale.List'). ' ' . Str::plural(__('locale.'.$page->title))); ?></span><i class="material-icons right">arrow_drop_down</i></a>
                          <ul class="dropdown-content" id="dropdown1" tabindex="0">
                            <li tabindex="0"><a class="grey-text text-darken-2 listBtn" data-type="active" href="javascript:" > <?php echo e(__('locale.Active')); ?> </a></li>
                            <li tabindex="0"><a class="grey-text text-darken-2 listBtn" data-type="inactive" href="javascript:"> <?php echo e(__('locale.Inactive')); ?> </a></li>
                          </ul>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col s12 m6 ">
                          <h4 class="card-title"><?php echo e(Str::singular($page->title) ?? ''); ?> List</h4>
                      </div>
                    </div>
                    <div class="row">
                        <form id="page-form" name="page-form">
                          <?php echo Form::hidden('status', '', ['id' => 'status'] ); ?>

                      </form>
                    </div>
                  </div>
                    <div id="view-borderless-table">
                      <div class="row">
                        <div class="col s12">
                          <table id="data-table-company" class="display data-tables" data-url="<?php echo e($page->link.'/lists'); ?>" data-form="page" data-length="30">
                            <thead>
                              <tr>
                                <th width="20px" data-orderable="false" data-column="DT_RowIndex"> No </th>
                                <th width="" data-orderable="false" data-column="name"> Name </th>
                                <th width="" data-orderable="false" data-column="contact_name"> Contact Name	 </th>
                                <th width="" data-orderable="false" data-column="email"> E-mail </th>
                                <th width="" data-orderable="false" data-column="contact"> Contact </th>
                                <th width="100px" data-orderable="false" data-column="status"> Status </th>
                                <th width="200px" data-orderable="false" data-column="action"> Action </th>
                              </tr>
                            </thead>
                          </table>
                        </div>
                      </div>
                    </div>
                  
              </div>
          </div>
      </div>
  </div>
</div><!-- START RIGHT SIDEBAR NAV -->
<?php echo $__env->make('companies.manage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('page-scripts'); ?>
<script src="<?php echo e(asset('admin/js/scripts/data-tables.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/custom/company/company.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/companies/list.blade.php ENDPATH**/ ?>
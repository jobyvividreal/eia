<?php $__env->startSection('seo_title', Str::plural(__('locale.Users')) ?? ''); ?> 
<?php $__env->startSection('search-title'); ?> <?php echo e(__('locale.Users') ?? ''); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('vendor-style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="col s12 m6 l6"><h5 class="breadcrumbs-title"><span><?php echo e(Str::plural(__('locale.Roles')) ?? ''); ?></span></h5></div>
<div class="col s12 m6 l6 right-align-md">
    <ol class="breadcrumbs mb-0">
        <li class="breadcrumb-item"><a href="<?php echo e(url(ROUTE_PREFIX.'/dashboard')); ?>"><?php echo e(__('locale.Dashboard')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url($page->route)); ?>"><?php echo e(Str::plural(__('locale.Users')) ?? ''); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(__('locale.View')); ?></li>
    </ol>
</div>
<?php $__env->stopSection(); ?>
<div class="section">
  <div class="card">
      <div class="card-content">
          <p class="caption mb-0"><?php echo e(__('messages.Dummy Text')); ?>.</p>
      </div>
  </div>

  <!-- Borderless Table -->
  <div class="row">
      <div class="col s12">
          <div id="borderless-table" class="card card-tabs">
              <div class="card-content data-table-container">
                  <div class="card-title">
                      <div class="row">
                        <div class="col s12 m6 ">
                            <h4 class="card-title">Manage <?php echo e($role->name); ?> Permissions </h4>
                        </div>
                      </div>
                  </div>
                  <div class="card-content">
                  
                    <?php echo Form::model($role, ['method' => 'PATCH', 'route' => ['admin.roles.update', $role->id]]); ?>

                      <?php echo csrf_field(); ?>
                      <div class="row">
                        <?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                        <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col m6 s12">
                          <?php echo Form::text('name',  $role->name ?? ''); ?> 
                          <!-- <label for="name" class="label-placeholder active">Role name <span class="red-text">*</span></label> -->
                        </div>
                        <div class="col m6 s12">
                          <button class="btn waves-effect waves-light" type="reset" name="reset">Reset <i class="material-icons right">refresh</i></button>
                          <button class="btn cyan waves-effect waves-light" type="submit" name="action" id="submit-btn">Submit <i class="material-icons right">send</i></button>
                        </div>
                        

                        <div class="col s12">                    
                          <ul class="collection with-header">
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li class="collection-header"><h6><?php echo e($value->name); ?></h6></li>
                                <?php $permission = Spatie\Permission\Models\Permission::where('parent', '=', $value->id)->get();  ?>
                                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if(($row->id == 33) && ($row->name == 'documents-manage-status') && ($role->id == 4 || $role->id == 1)): ?>
                                    <li class="collection-item">
                                      <div><?php echo e($row->name); ?>

                                        <a href="#!" class="secondary-content">
                                          <?php 
                                            $checked  = '';
                                            $checked  = in_array($row->id, $rolePermissions) ? "checked" : "";
                                          ?>
                                          <p class=""><label><input type="checkbox" class="payment-types filled-in" name="permission[]" data-type="<?php echo e($row->id); ?>" id="permission<?php echo e($row->id); ?>" <?php echo e(in_array($row->id, $rolePermissions) ? "checked" : ""); ?> value="<?php echo e($row->id); ?>"><span></span></label></p>
                                        </a>
                                      </div>
                                    </li>
                                  <?php elseif(($row->id != 33) && ($row->name != 'documents-manage-status')): ?>
                                    <li class="collection-item">
                                        <div><?php echo e($row->name); ?>

                                          <a href="#!" class="secondary-content">
                                            <?php 
                                              $checked  = '';
                                              $checked  = in_array($row->id, $rolePermissions) ? "checked" : "";
                                            ?>
                                            <p class=""><label><input type="checkbox" class="payment-types filled-in" name="permission[]" data-type="<?php echo e($row->id); ?>" id="permission<?php echo e($row->id); ?>" <?php echo e(in_array($row->id, $rolePermissions) ? "checked" : ""); ?> value="<?php echo e($row->id); ?>"><span></span></label></p>
                                          </a>
                                        </div>
                                      </li>
                                  <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                        </div>
                        
                      </div>
                    <?php echo Form::close(); ?>

                  </div>

              </div>
          </div>
      </div>
  </div>
</div><!-- START RIGHT SIDEBAR NAV -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
<script src="<?php echo e(asset('admin/js/scripts/data-tables.js')); ?>"></script>
<script>
$('#roles').select2({ placeholder: "Please choose roles", allowClear: true });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shamsherahamza/Downloads/eia-main/resources/views/admin/roles/edit.blade.php ENDPATH**/ ?>